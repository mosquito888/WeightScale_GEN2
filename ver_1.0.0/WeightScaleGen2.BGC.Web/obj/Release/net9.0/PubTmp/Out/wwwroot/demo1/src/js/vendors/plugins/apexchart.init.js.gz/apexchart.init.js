﻿Apex.xaxis = {
    labels: {
        style: {
           fontFamily: 'Montserrat'
        }
    }
 }