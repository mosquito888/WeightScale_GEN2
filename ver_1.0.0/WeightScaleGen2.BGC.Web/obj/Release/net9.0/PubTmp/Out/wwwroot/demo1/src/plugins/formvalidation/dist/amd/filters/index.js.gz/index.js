﻿define(["require", "exports", "./getFieldValue"], function (require, exports, getFieldValue_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = {
        getFieldValue: getFieldValue_1.default,
    };
});
